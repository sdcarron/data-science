
getwd ()

setwd ("C:/Users/Steve/Desktop/Stat 451/2017/inClassExample")


data <- read.table ("chd.dat", header=TRUE)
head (data)
data



#plot (density (data$CHD))


logisticRegression_model <- "model{
  for (i in 1:8)
  {
    CHD [i] ~ dbin (p [i], nRisk[i])

    logit (p [i]) <- beta0 + betaCat*Cat [i] + betaAge*agegrp [i] #+ betaECG*abECG [i]
  }


  beta0 ~ dnorm (0, .001)
  betaCat ~ dnorm (0, .001)
  betaAge ~ dnorm (0, .001)
  #betaECG ~ dnorm (0, .001)
  
}"



writeLines (logisticRegression_model, "logisticRegression.txt")


data
p <- data$CHD/data$nRisk
Cat <- data$Cat
CHD <- data$CHD
agegrp <- data$agegrp
#abECG <- data$abECG
n <- length (data$nRisk)
nRisk <- data$nRisk

data.jags <- c("Cat", "agegrp",  "nRisk", "CHD") #"abECG",


parms <- c ("beta0", "betaCat", "betaAge") #, "betaECG"



logisticRegression.sim <- jags (data=data.jags, inits=NULL, parameters.to.save=parms, model.file="logisticRegression.txt", n.iter=30000, n.burnin=5000, n.chains=4, n.thin=4)


logisticRegression.sim


#The 95% Credible Intervals for both betaCat and betaECG contained 0, suggesting that we cannot
#conclude that either is different from 0. However, I will first remove betaECG because it has
#the wider 95% Credible Interval about 0.

#Once I removed betaECG, the 95% Credible Interval for betaCat no longer included 0, so I will
#keep the model that only has betaECG missing


# I conclude that as betaAge increases by 1 unit, then p is increased by a factor between e^.046 and e^1.181
# I conclude that as betaCat increases by 1 unit, then p is increased by a factor between e^.565 and e^1.344
# I conclude that beta0's effect on p is a factor between e^-2.967 and e^-2.169


logisticRegression_MCMC <- as.mcmc (logisticRegression.sim)


logisticRegression_matrix <- as.matrix (logisticRegression_MCMC)

head (logisticRegression_matrix)

effectiveSize (logisticRegression_matrix) #The Effective Sizes are all nearly 3000 or greater
raftery.diag (logisticRegression_matrix) #The Raftery Dependence Factors are all less than 5, but beta0 is close to 5
autocorr.diag (logisticRegression_matrix)
autocorr (logisticRegression_MCMC) #Auto Correlation seems to be somewhat ok
