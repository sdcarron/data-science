#Updated Model
getwd ()
setwd ("C:/Users/Steve/Desktop/Stat 451/2017/inClassExample")

data <- read.table ("chd.dat", header=TRUE)

mdl <- "model{

  for (i in 1:8)
  {
    CHD [i] ~ dbin (p [i], nRisk [i])

    logit (p [i]) <- b [tmt [i]]

    b [i] ~ dnorm (-2, .1)
  }

}"



#Dr Fellingham added a column "tmt" (the number 1 - 8) to his chd.dat data set
tmt <- seq (1:8)
data <- cbind (data, tmt)
data

p <- data$CHD/data$nRisk
CHD <- data$CHD
ECG <- data$abECG
cat <- data$Cat
ageGrp <- data$agegrp
nRisk <- data$nRisk

data.jags <- c ("tmt", "CHD", "ECG", "ageGrp", "nRisk", "Cat")

parms <- c ("b")


writeLines (mdl, "updatedLogisticRegression.txt")


updatedLogisticRegression.sim <- jags (data=data.jags, inits=NULL, parameters.to.save=parms, model.file="updatedLogisticRegression.txt", n.iter=3500, n.burnin=1000, n.chains=4, n.thin=1)


#Effect of age: (p1+p3+p5+p7)/4 - (p2+p4+p6+p8)/4
#Effect of Cat: (p1+p2+p3+p4)/4 - (p5+p6+p7+p8)/4
#Effect of ECG: (p1+p2+p5+p6)/4 - (p3+p4+p7+p8)/4
#EFfect of Cat x ECG: (p1+p2-p3-p4-p5-p6+p7+p8)


updatedLogisticRegression.sim



updatedLogisticRegression_MCMC <- as.mcmc (updatedLogisticRegression.sim)

updatedLogisticRegression_matrix <- as.matrix (updatedLogisticRegression_MCMC)

head (updatedLogisticRegression_matrix)


b1 <- updatedLogisticRegression_matrix [,1]
head (b1)

b2 <- updatedLogisticRegression_matrix [,2]
b3 <- updatedLogisticRegression_matrix [,3]
b4 <- updatedLogisticRegression_matrix [,4]
b5 <- updatedLogisticRegression_matrix [,5]
b6 <- updatedLogisticRegression_matrix [,6]
b7 <- updatedLogisticRegression_matrix [,7]
b8 <- updatedLogisticRegression_matrix [,8]

p1 <- exp (b1) / (1 + exp (b1))
p2 <- exp (b2) / (1 + exp (b2))
p3 <- exp (b3) / (1 + exp (b3))
p4 <- exp (b4) / (1 + exp (b4))
p5 <- exp (b5) / (1 + exp (b5))
p6 <- exp (b6) / (1 + exp (b6))
p7 <- exp (b7) / (1 + exp (b7))
p8 <- exp (b8) / (1 + exp (b8))



#Check Treatment Effects

#Cat
effect_Cat <- (p1+p2+p3+p4)/4 - (p5+p6+p7+p8)/4
mean (effect_Cat > 0)


#ECG
effect_ECG <- (p1+p2+p5+p6)/4 - (p3+p4+p7+p8)/4
mean (effect_ECG > 0)


#Age
effect_Age <- (p1+p3+p5+p7)/4 - (p2+p4+p6+p8)/4
mean (effect_Age > 0)


#Interaction Cat x ECG
effect_Cat_ECG <- p1+p2-p3-p4-p5-p6+p7+p8
mean (effect_Cat_ECG > 0)


#Interaction Cat x Age
effect_Cat_Age <- p1-p2+p3-p4-p5+p6-p7+p8
mean (effect_Cat_Age > 0)


#Interaction ECG x Age
effect_ECG_Age <- p1-p2-p3+p4+p5-p6-p7+p8
mean (effect_ECG_Age > 0)


#Interaction Cat x ECG x Age
effect_Cat_ECG_Age <- p1-p2-p3+p4-p5+p6+p7-p8
mean (effect_Cat_ECG_Age > 0)
