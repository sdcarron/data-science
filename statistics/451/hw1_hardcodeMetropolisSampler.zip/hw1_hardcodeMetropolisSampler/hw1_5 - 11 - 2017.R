dat <- read.table ("linreg.dat", header=FALSE)
dat

class (dat)

colnames(dat) <- c ("man_hours", "lot_size")
dat


actualModel <- lm (dat$lot_size ~ dat$man_hours)
actualModel

summary (actualModel)

plot (dat)
abline (actualModel, col='red', type='l')

curve (dgamma (x, shape=10, scale=2))






logCompleteBeta_0 <- function (data_y, data_x, sigmaSquared_computed, sigmaSquared_beta_0_prior, beta_0_computed, beta_1_computed, mu_beta_0_prior)
{
  (-1/(2*sigmaSquared_computed))*sum ((data_y - (beta_0_computed + (beta_1_computed*(data_x))))^2) - (1/(2*sigmaSquared_beta_0_prior))*((beta_0_computed - mu_beta_0_prior)^2)
}



logCompleteBeta_1 <- function (data_y, data_x, sigmaSquared_computed, sigmaSquared_beta_1_prior, beta_0_computed, beta_1_computed, mu_beta_1_prior)
{
  (-1/(2*sigmaSquared_computed))*sum ((data_y - (beta_0_computed + (beta_1_computed*(data_x))))^2) - (1/(2*sigmaSquared_beta_1_prior))*((beta_1_computed - mu_beta_1_prior)^2)
}



logCompleteSigmaSquared <- function (data_y, data_x, sigmaSquared_computed, beta_0_computed, beta_1_computed, alphaSigmaSquared, betaSigmaSquared)
{
  -(length (data_y)/2)*log (sigmaSquared_computed) - (1/(2*sigmaSquared_computed))*sum ((data_y - (beta_0_computed + beta_1_computed*(data_x)))^2) + (alphaSigmaSquared - 1)*log (sigmaSquared_computed) - (sigmaSquared_computed/betaSigmaSquared)
}






metropolis_HW <- function (data, nLoops, candidateSigma_beta_0, candidateSigma_beta_1, candidateSigma_sigmaSquared, mu_beta_0_prior, mu_beta_1_prior, sigmaSquared_beta_0_prior, sigmaSquared_beta_1_prior, alpha_sigmaSquared_prior, beta_sigmaSquared_prior)
{
  count_beta_0 <- 1
  count_beta_1 <- 1
  count_sigmaSquared <- 1
  
  
  
  #Arrange an output matrix, filled with 0's, with num rows = nLoops, beta_0 in first column, beta_1 in second column, sigmaSquared in third column
  out <- matrix (0, nLoops, 3)
  
  
  #Looking at the data sent by Dr. Fellingham, and constructing a linear model, the estimate for beta_0 is 10
  out [1,1] <- 10
  
  #Looking at the data sent by Dr. Fellingham, and constructing a linear model, the estimate for beta_1 is 2
  out [1,2] <- 2
  
  #Looking at the data sent by Dr. Fellingham, and constructing a linear model, the estimate for sigmaSquared is (2.739)^2
  out [1,3] <- (2.739)^2
  
  
  for (i in 2:nLoops)
  {
    #Update beta_0
    out[i,1] <- out[i-1,1]
    
    #Compute a NEW POTENTIAL estimate for beta_0 from normal distribution with mean=previous beta_0 estimate and candidateSigma for beta_0
    newCandidate_beta_0 <- rnorm (1, out[i-1,1], candidateSigma_beta_0)
    
    #Compute r1 term passing in data_y, data_x, MOST RECENT sigmaSquared parameter estimate (out[i-1,3]),
    #sigmaSquared for prior on beta_0, the NEW candidate for beta_0 estimate, the MOST RECENT beta_1 parameter estimate (out[i-1,2]),
    #AND the mu for prior on beta_0
    r1_beta_0 <- logCompleteBeta_0 (dat$lot_size, dat$man_hours, out[i-1,3], sigmaSquared_beta_0_prior, newCandidate_beta_0, out[i-1,2], mu_beta_0_prior)
    
    #Do the same as above EXCEPT instead of using the NEW candidate for beta_0 estimate, use the PREVIOUS estimate
    r2_beta_0 <- logCompleteBeta_0 (dat$lot_size, dat$man_hours, out[i-1,3], sigmaSquared_beta_0_prior, out[i-1,1], out[i-1,2], mu_beta_0_prior)
    
    r_beta_0 <- r1_beta_0 - r2_beta_0
    
    if (r_beta_0 > log (runif (1, 0, 1)))
    {
      out[i,1] <- newCandidate_beta_0
      
      count_beta_0 <- count_beta_0 + 1
    }
    
    
    
    
    #Update beta_1
    out[i,2] <- out[i-1,2]
    
    #Compute a NEW POTENTIAL estimate for beta_1 from normal distribution with mean=previous beta_1 estimate and candidateSigma for beta_1
    newCandidate_beta_1 <- rnorm (1, out[i-1,2], candidateSigma_beta_1)
    
    #Compute r1 term passing in data_y, data_x, MOST RECENT sigmaSquared parameter estimate (out[i-1,3]),
    #sigmaSquared for prior on beta_1, the MOST RECENT parameter estimate for beta_0 (out[i,1]), the NEW canddiate for beta_1,
    #AND the mu for prior on beta_1
    r1_beta_1 <- logCompleteBeta_1 (dat$lot_size, dat$man_hours, out[i-1,3], sigmaSquared_beta_1_prior, out[i,1], newCandidate_beta_1, mu_beta_1_prior)
    
    #Do the same as above EXCEPT instead of using the NEW candidate for beta_1 estimate, use the PREVIOUS estimate
    r2_beta_1 <- logCompleteBeta_1 (dat$lot_size, dat$man_hours, out[i-1,3], sigmaSquared_beta_1_prior, out[i,1], out[i-1,2], mu_beta_1_prior)
    
    r_beta_1 <- r1_beta_1 - r2_beta_1
    
    if (r_beta_1 > log (runif (1, 0, 1)))
    {
      out[i,2] <- newCandidate_beta_1
      
      count_beta_1 <- count_beta_1 + 1
    }
    
    
    
    
    #Update sigmaSquared
    out[i,3] <- out[i-1,3]
    
    newCandidate_sigmaSquared <- rnorm (1, out[i-1,3], candidateSigma_sigmaSquared)
    
    if (newCandidate_sigmaSquared > 0)
    {
      r1_sigmaSquared <- logCompleteSigmaSquared (dat$lot_size, dat$man_hours, newCandidate_sigmaSquared, out[i,1], out[i,2], alpha_sigmaSquared_prior, beta_sigmaSquared_prior)
      
      r2_sigmaSquared <- logCompleteSigmaSquared (dat$lot_size, dat$man_hours, out[i-1,3], out[i,1], out[i,2], alpha_sigmaSquared_prior, beta_sigmaSquared_prior)
      
      r_sigmaSquared <- r1_sigmaSquared - r2_sigmaSquared
      
      if (r_sigmaSquared > log (runif (1, 0, 1)))
      {
        out[i,3] <- newCandidate_sigmaSquared
        
        count_sigmaSquared <- count_sigmaSquared + 1
      } 
    }
  }
  
  
  
  cat ('proportion accepted beta_0: ', count_beta_0/nLoops, '\n')
  cat ('proportion accepted beta_1: ', count_beta_1/nLoops, '\n')
  cat ('proportion accepted sigmaSquared: ', count_sigmaSquared/nLoops, '\n')
  
  return (out)
}



#metropolis (data, nLoops, candidateSigma_beta_0, candidateSigma_beta_1, candidateSigma_sigmaSquared, sigmaSquared_beta_0_prior, sigmaSquared_beta_1_prior, mu_beta_0_prior, mu_beta_1_prior, alpha_sigmaSquared_prior, beta_sigmaSquared_prior)
result <- metropolis_HW (dat, 10000, 4, .07, 9, 6, .03, 10, 2, .6, 4)

estimate_beta_0 <- mean (result[,1])
estimate_beta_0 #The estimate for beta_0 is 8.793822
quantile (result[,1], c(.025, .975)) #The 95% probability interval for beta_0 is 4.976367 to 12..673771

estimate_beta_1 <- mean (result[,2])
estimate_beta_1 #The estimate for beta_1 is 2.020989
quantile (result[,2], c(.025, .975)) #The 95% probability interval for beta_1 is 1.949466 to 2.094744

estimate_sigmaSquared <- mean (result[,3])
estimate_sigmaSquared #The estimate for sigmaSquared (sigma) is 6.791631
quantile (result[,3], c(.025, .975)) #The 95% probability interval for sigma is 2.940047 to 13.707304

#2.5^2 = prior variance for beta_0... std error beta_0 = 2.50294
#.04697^2 = prior variance for beta_1... std error beta_1 = .04697 
#2.739^2 = prior variance for sigmaSquared... std error sigmaSquared = 2.739
dat$lot_size
dat$man_hours