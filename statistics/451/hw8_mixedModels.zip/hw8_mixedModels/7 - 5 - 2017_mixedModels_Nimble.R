getwd ()
setwd ("C:/Users/Steve/Desktop/Stat 451/2017/hw8_mixedModels")


library ('nimble')


data <- read.table ('bond.dat', header=TRUE)

#data$ingot <- as.factor (data$ingot)

data$nickel <- as.numeric (data$metal == 'n')
data$iron <- as.numeric (data$metal == 'i')
data$copper <- as.numeric (data$metal == 'c')

data$ingot1 <- as.numeric (data$ingot == 1)
data$ingot2 <- as.numeric (data$ingot == 2)
data$ingot3 <- as.numeric (data$ingot == 3)
data$ingot4 <- as.numeric (data$ingot == 4)
data$ingot5 <- as.numeric (data$ingot == 5)
data$ingot6 <- as.numeric (data$ingot == 6)
data$ingot7 <- as.numeric (data$ingot == 7)

rm (nickel)
rm (iron)
rm (copper)

dFrame <- data.frame (data)
dFrame

mixedModel_nimble <- nimbleCode ({
  
  for (i in 1:21)
  {
    pressure [i] ~ dnorm (mn [i], 1/s2)
    
    mn [i] <- mu[1]*nickel[i] + mu[2]*iron[i] + mu[3]*copper[i] + u[1]*ingot1[i] + u[2]*ingot2[i] + u[3]*ingot3[i] + u[4]*ingot4[i] + u[5]*ingot5[i] + u[6]*ingot6[i] + u[7]*ingot7[i]
  }
  
  for (j in 1:3)
  {
    mu[j] ~ dnorm (0, .001)  
  }
  
  for (k in 1:7)
  {
    u[k] ~ dnorm (0, 1/s2U)  
  }
  
  
  s2 ~ dgamma (1.5, .2)
  s2U ~ dgamma (1.5, .2)
})

data

dataSubmit <- rep (0, nrow (data))

for (i in 3:ncol (data))
{
  dataSubmit <- cbind (dataSubmit, data[,i])
}

dataSubmit
dataSubmit <- dataSubmit [,-1]
dataSubmit

colnames (dataSubmit) <- c ('pressure', 'nickel', 'iron', 'copper', 'ingot1', 'ingot2', 'ingot3', 'ingot4', 'ingot5', 'ingot6', 'ingot7')

dFrame <- data.frame (dataSubmit)

n <- nrow (dataSubmit)

dataConsts <- list (n=n)

dataInits <- NULL

mixedModel <- nimbleModel (code=mixedModel_nimble, name='mixedModel_nimble', data=dFrame, inits=dataInits, constants=dataConsts)



initCompile <- compileNimble (mixedModel, showCompilerOutput=TRUE)

configureMixedModel <- configureMCMC (mixedModel, print=TRUE, thin=2)



buildMixedModel <- buildMCMC (configureMixedModel)

compileMixedModel <- compileNimble (buildMixedModel)



niter <- 40000
set.seed (0)
compileMixedModel$run (niter)

chains <- as.matrix (compileMixedModel$mvSamples)
nrow (chains) #nrow should be 20,000 because of niter=40000 with thin=2

chains <- chains [5001:nrow (chains) - 1,]
nrow (chains) #nrow should be 15,000 because 20,000 - nburnin=5,000





