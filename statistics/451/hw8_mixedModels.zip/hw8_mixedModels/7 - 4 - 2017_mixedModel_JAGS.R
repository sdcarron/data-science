getwd ()
setwd ("C:/Users/Steve/Desktop/Stat 451/2017/hw8_mixedModels")

#The Mixed Model inclass example is "6 - 27 - 2017_CultivarData_CompleteAnalysis"


data <- read.table ("bond.dat", header=TRUE)

data

tmt <- as.numeric (data$metal)
tmt

data$tmt <- tmt
data
#We are constructing a Mixed Model, which means that we have a FIXED variable and a RANDOM variable
#and we INCLUDE the FIXED variable in our model (as well as RANDOM variable) so that we can
#make inference across all levels of the FIXED variable


mixedModel <- "model{

  for (i in 1:n)
  {
    pressure [i] ~ dnorm (mn [i], 1/s2)

    mn [i] <- mu [tmt [i]] + u [ingot [i]]
  }

  for (j in 1:3)
  {
    mu [j] ~ dnorm (0, .001)
  }

  for (k in 1:7)
  {
    u [k] ~ dnorm (0, 1/s2U)
  }

  s2 ~ dgamma (1.5, .2)

  s2U ~ dgamma (1.5, .2)

}"

writeLines (mixedModel, "mixedModel.txt")

n <- nrow (data)

tmt <- data$tmt
ingot <- data$ingot
pressure <- data$pressure

tmt
ingot
data.jags <- c ("n", "ingot", "tmt", "pressure")

parms <- c ("s2", "s2U", "mu")


mixedModel.sim <- jags (data=data.jags, inits=NULL, parameters.to.save=parms, model.file="mixedModel.txt", n.iter=12000, n.burnin=1000, n.chains=4, n.thin=3)


mixedModel.sim


mixedModel_MCMC <- as.mcmc (mixedModel.sim)

effectiveSize (mixedModel_MCMC)
autocorr.diag (mixedModel_MCMC)



mixedModel_Matrix <- as.matrix (mixedModel_MCMC)

raftery.diag (mixedModel_Matrix)


head (mixedModel_Matrix)

mu1 <- mixedModel_Matrix[,2]
head (mu1)

mu2 <- mixedModel_Matrix[,3]
head (mu2)

mu3 <- mixedModel_Matrix[,4]
head (mu3)

diff_mu1_mu2 <- mu1 - mu2
plot (density (diff_mu1_mu2))
mean (diff_mu1_mu2 > 0)

diff_mu2_mu3 <- mu2 - mu3
plot (density (diff_mu2_mu3))
mean (diff_mu2_mu3 > 0)

diff_mu1_mu3 <- mu1 - mu3
plot (density (diff_mu1_mu3))
mean (diff_mu1_mu3)

#I conclude that mu2 displays the GREATEST effect on bond (pressure), and mu2 is associated
#with iron

#I conclude that mu3 displays the SECOND GREATEST effect on bond (pressure), and mu3 is
#associated with copper

#I conclude that mu1 displays the WEAKEST effect on bond (pressure), and mu1 is associated
#with nickel