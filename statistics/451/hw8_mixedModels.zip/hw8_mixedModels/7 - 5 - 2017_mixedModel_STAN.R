getwd ()
setwd ("C:/Users/Steve/Desktop/Stat 451/2017/hw8_mixedModels")

library ('rstan')


data <- read.table ('bond.dat', header=TRUE)


tmt <- as.numeric (data$metal)
data$tmt <- tmt

data

pressure <- data$pressure
ingot <- data$pressure
tmt <- data$tmt

N <- nrow (data)


mixedModel_List <- list (N=N, pressure=pressure, ingot=ingot, tmt=tmt)

fit <- stan (file='7 - 5 - 2017_mixedModels_STAN.stan', data=data, iter=12000, warmup=2000, chains=4)
