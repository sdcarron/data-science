getwd ()
 
setwd ("C:/Users/Steve/Desktop/Stat 451/2017/hw6_ANOVA") 


data <- read.table ("cult.dat", header=FALSE)

library ("R2jags")


#I added in an extra column that will be labeled "cell". This will identify in which
#cell in the 3x2 ANOVA table each data point belongs
data <- cbind (data, rep (0, length (data[,1])))

#Verify that the new column was inserted as intended
#head (data)

#Insert labels so that identifying a data point is easier
colnames (data) <- c ("ignore", "treatment", "additive", "yield", "cell")

#Verify that the labels were inserted as intended
#head (data)


#Assign the correct 3x2 ANOVA table cell group for each data point. This will allow
#for defining y[i] ~ dnorm (mu [cell [i]], s2) in JAGS
for (i in 1:length (data$additive))
{
  if (data$additive [i] == "con")
  {
    
    if (data$treatment [i] == "a")
    {
      data$cell [i] <- 1
    } else
    {
      data$cell [i] <- 2
    }
    
  } else if (data$additive [i] == "dea")
  {
    
    if (data$treatment [i] == "a")
    {
      data$cell [i] <- 3
    } else
    {
      data$cell [i] <- 4
    }
    
  } else if (data$additive [i] == "liv")
  {
    
    if (data$treatment [i] == "a")
    {
      data$cell [i] <- 5
    } else
    {
      data$cell [i] <- 6
    }
    
  } else
  {
    
  }
}

#Verify that each data point received the intended cell group in the 3x2 table
head (data)
data



model <- "model {
  
  for (i in 1:n)
  {
    #Assigning each data point to an appropriate cell group in the 3x2 table allowed for
    #mu to depend on only one value
    y[i] ~ dnorm (mu [cell [i]], 1/s2)
  }

  
  #Assigning each data point to an appropriate cell group in the 3x2 table resulted in
  #defining 6 different priors for mu
  for (j in 1:6)
  {
    mu [j] ~ dnorm (30, .0001)
  }

  s2 ~ dgamma (1.5, .2)
}"


writeLines (model, "hw6_bayAnova.txt")

cell <- data$cell
y <- data$yield
n <- length (data$yield)

data.jags <- c ("cell", "y", "n")

parms <- c ("mu", "s2")


anova.sim <- jags (data=data.jags, inits=NULL, parameters.to.save=parms, model.file="hw6_bayAnova.txt", n.iter=3500, n.burnin=1000, n.chains=4, n.thin=1)



anova.sim

effectiveSize (anova.sim)


anovaMCMC <- as.mcmc (anova.sim)

#Effective Size shows satisfactory results for all parameters except s2
effectiveSize (anovaMCMC)
raftery.diag (anovaMCMC)

#Raftery and Autocorr show satisfactory results for all parameters
anovaMCMC_matrix <- as.matrix (anovaMCMC)
raftery.diag (anovaMCMC_matrix)

autocorr.diag (anovaMCMC)


#Because Raftery and Autocorr show satisfactory results for all parameters and Effective Size shows
#satisfactory results for all parameters except s2, we'll conclude that convergence occurred satisfactorily





#Extract the seperate cell mu's
mu1 <- anovaMCMC_matrix [,2]
mu2 <- anovaMCMC_matrix [,3]
mu3 <- anovaMCMC_matrix [,4]
mu4 <- anovaMCMC_matrix [,5]
mu5 <- anovaMCMC_matrix [,6]
mu6 <- anovaMCMC_matrix [,7]
s2 <- anovaMCMC_matrix [,8]




#Check for interaction
#Break these up into mu1 - mu2, mu3 - mu4, and mu5 - mu6 and make comparisons between the pairs
#After comparing the pairs of treatment and additive combinations, we concluded that there appear
#to be NO interactions between treatment and additive--all of the 95% Credible Intervals contain 0
muInteraction_12_34 = mu1 - mu2 - mu3 + mu4

plot (density (muInteraction_12_34))
mean (muInteraction_12_34 > 0)
mean (muInteraction_12_34 < 0)
quantile (muInteraction_12_34, c (.025, .975))

muInteraction_34_56 = mu3 - mu4 - mu5 + mu6

plot (density (muInteraction_34_56))
mean (muInteraction_34_56 > 0)
mean (muInteraction_34_56 < 0)
quantile (muInteraction_34_56, c (.025, .975))

muInteraction_12_56 = mu1 - mu2 - mu5 + mu6
plot (density (muInteraction_12_56))
mean (muInteraction_12_56 > 0)
mean (muInteraction_12_56 < 0)
quantile (muInteraction_12_56, c (.025, .975))



#check for main effects


#Look at main effect for TREATMENT (i.e. "a" or "b")
#It appears treatment "a" is worse than treatment "b"
tmtA <- (mu1 + mu3 + mu5)/3 - (mu2 + mu4 + mu6)/3
plot (density (tmtA)) 
mean (tmtA > 0)




#Look at main effect for ADDITIVE (i.e. "con", "dea", or "liv")
additive_1 <- (mu1 + mu2)/2
additive_2 <- (mu3 + mu4)/2
additive_3 <- (mu5 + mu6)/2

#It appears additive_1 is worse than additive_2
additiveA <- additive_1 - additive_2
plot (density (additiveA))
mean (additiveA > 0)

#It appears additive_1 is also worse than additive_3
additiveB <- additive_1 - additive_3
plot (density (additiveB))
mean (additiveB > 0)

#It appears additive_2 is worse than additive_3
additiveC <- additive_2 - additive_3
plot (density (additiveC))
mean (additiveC > 0)
