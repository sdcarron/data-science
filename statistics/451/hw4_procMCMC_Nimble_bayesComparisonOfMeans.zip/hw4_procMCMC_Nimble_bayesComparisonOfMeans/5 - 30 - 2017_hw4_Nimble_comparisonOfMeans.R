#Due a week from 5 - 30 - 2017: THIS file AND this same problem done in STAN


library ('nimble')

twogrpsCode <- nimbleCode ({
  
  for (i in 1:n)
  {
    y [i] ~ dnorm (mu[x [i]], sd=s [x [i]])
  }
  
  for (j in 1:2)
  {
    mu [j] ~ dnorm (120, 10000)
    s [j] ~ dunif (0, 100)
  }
  
})

twoGrps <- read.table ('example2.dat', header=FALSE)
class (twoGrps)
colnames (twoGrps) <- c ('x', 'y')


twogrpsData <- list (y=twoGrps$y)
twogrpsConstants <- list (n=33, n1=1, n2=2, tmt=twoGrps$x)
twogrpsInits <- NULL

twogrpsModel <- nimbleModel (code=twogrpsCode, name='twogrpsEx', data=twogrpsData, inits=twogrpsInits, constants=twogrpsConstants)




plot (twogrpsModel$graph)


Ctwogrps <- compileNimble (twogrpsModel)





twogrpsConf <- configureMCMC (twogrpsModel, print=TRUE, thin=10)

twogrpsConf_Ctwogrps <- configureMCMC (Ctwogrps, print=TRUE, thin=10)




twogrpsMCMC <- buildMCMC (twogrpsConf)





CtwogrpsMCMC <- compileNimble (twogrpsMCMC, project=twogrpsModel, resetFunctions=TRUE)




niter <- 120000

set.seed (0)

CtwogrpsMCMC$run (niter)


samples <- as.matrix (CtwogrpsMCMC$mvSamples)
samples <- samples [2001:12000,]




library (coda)
sims <- as.mcmc (samples)
#mudif <- samples [,1] - samples [,2]
#plot (density (mudif)) #this is a density plot for a difference between the posterior means

#sddif <- samples [,3] - samples [,4]
#plot (density (sddif)) #this is a density plot for a difference between the posterior std deviations

#Can compare the posterior variances similar to how Stat 121 (frequentist) do it by doing this:
#var1 <- samples [,3] ^ 2
#var2 <- samples [,4] ^ 2
#varRatio <- var1 / var2
#mean (varRatio > 2) #the frequentist rule is that if one Var is greater than 2X other Var, can't assume equal variance