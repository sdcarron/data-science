procMCMC_sameVariance_chains <- read.csv ('example2.csv')

procMCMC_differentVariance_chains <- read.csv ('example2_differentVariance.csv')


#Do the comparison of means and variances using the Chain objects (posterior distributions)


#Do the diagnostics using an MCMC object created FROM the chain objects


head (procMCMC_sameVariance_chains)

#Identify process needed to isolate columns of interest from the procMCMC object
#class (procMCMC_sameVariance_chains)
#head (procMCMC_sameVariance_chains [1]) #This command pulls the first column from the dataframe


muDifference_sameVariance <- procMCMC_sameVariance_chains [2] - procMCMC_sameVariance_chains [3]

head (muDifference_sameVariance)
class (muDifference_sameVariance)

quantile (muDifference_sameVariance [,1], c (.025, .975)) #The 95% Credible Interval for the difference between the two means
#is from 4.0 to 22.6, which does NOT contain 0, so I conclude the means of the two different distributions are different


#Convert the Posterior Distribution CHAINS to an MCMC object in order to perform diagnostics
procMCMC_sameVariance_chains_conversionMCMC <- as.mcmc (procMCMC_sameVariance_chains)

effectiveSize (procMCMC_sameVariance_chains_conversionMCMC) #Each of the parameters has an Effective Size > 5000,
#which is acceptable

raftery.diag (procMCMC_sameVariance_chains_conversionMCMC)#The Dependenc Factor for each parameter is quite poor
#Each parameter has a Dependence Factor value near 5, which is not good at all. Ideally, these values should be near 1.

autocorr.diag (procMCMC_sameVariance_chains_conversionMCMC) #Auto Correlation does not appear to be a problem
#for any of the parameters






head (procMCMC_differentVariance_chains)

muDifference_differentVariance <- procMCMC_differentVariance_chains [2] - procMCMC_differentVariance_chains [3]
#head (muDifference_differentVariance)
quantile (muDifference_differentVariance [,1], c (.025, .975)) #The 95% Credible Interval does NOT contain 0,
#so I conclude that the means of the two different distributions are different

s2Ratio_differentVariance <- procMCMC_differentVariance_chains [4] / procMCMC_differentVariance_chains [5]
quantile (s2Ratio_differentVariance [,1], c (.025, .975)) #The 95% Credible Interval for the RATIO between the
#variances for the two different distributions is from 3.038909 to 10.738477 so I conclude that the variances
#are not equal because the ratio of 2 is not even in the 95% Credible Interval for the ratio


#Convert the Posterior Distribution CHAINS to an MCMC object in order to perform diagnostics
procMCMC_differentVariance_chains_conversionMCMC <- as.mcmc (procMCMC_differentVariance_chains)

effectiveSize (procMCMC_differentVariance_chains_conversionMCMC) #Each of the parameters of interest appears to have
#an acceptable effective size

raftery.diag (procMCMC_differentVariance_chains_conversionMCMC) #The Dependenc Factor for each parameter is quite poor
#Each parameter has a Dependence Factor value near 5, which is not good at all. Ideally, these values should be near 1.

autocorr.diag (procMCMC_differentVariance_chains_conversionMCMC) #Auto Correlation does NOT appear to be an issue
#for any of the parameters of interest


density (procMCMC_differentVariance_chains [2])



