data <- read.table ('example2.dat')
data


colnames (data) <- c ('treatment', 'response')
head (data)


mdl_sameVariance <- "model{

  for (i in 1:33)
  {
    y[i] ~ dnorm (mu_sameVariance [x [i]], precision_sameVariance)
  }


  precision_sameVariance <- 1/sigmaSquared_sameVariance

  sigmaSquared_sameVariance ~ dgamma (1.5, 1/10) #shape = 1.5, scale = 1/(1/10) = 10

  for (j in 1:2)
  {
    mu_sameVariance [j] ~ dnorm (120, 1/10000) #JAGS uses paramteres for the Normal distribution of mean (120) and precision = 1/variance (want variance of 10,000? precision = 1/10,000)
  }

}"


writeLines (mdl_sameVariance, 'bayComparisonMeans_freq2SampleTTest_sameVariance.txt')

x <- data$treatment
y <- data$response

data.jags <- c ('x', 'y')

parms <- c ('mu_sameVariance', 'sigmaSquared_sameVariance')


comparison.sim <- jags (data=data.jags, inits=NULL, parameters.to.save=parms, model.file='bayComparisonMeans_freq2SampleTTest_sameVariance.txt', n.iter=3500, n.burnin=1000, n.chains=4, n.thin=1)

comparison.sim #Rhat values are all at about 1, which is what we would like to see


effectiveSize (comparison.sim) #effectiveSize > 5000 for mu1, mu2, and s2 so effectiveSize is good

comparisonMCMC <- as.mcmc (comparison.sim)
autocorr (comparisonMCMC) #autocorrelation doesn't appear to indicate any issues

raftery.diag (comparisonMCMC)

chains <- as.matrix (comparisonMCMC)
comparison1 <- as.mcmc (chains)

raftery.diag (comparison1) #raftery Dependence Factors are all much smaller than 5


head (chains)
differenceMu_sameVariance <- chains [,2] - chains [,3]

quantile (differenceMu_sameVariance, c (.025, .975)) #The 95% Credible Interval is from 3.875345 to 22.737076,
#which does NOT contain 0, so I conclude that the means are NOT the same







mdl_differentVariance <- "model{

  for (i in 1:33)
  {
    y[i] ~ dnorm (mu_differentVariance [x [i]], precision_differentVariance [x [i]])
  }


  #We set the Means and Variances to be the same for the 2 different Mean and 2 different Variance PRIOR
  #distributions because WE DON'T KNOW if they're different (the NULL hypothesis is that there is NO difference)
  for (j in 1:2)
  {
    sigmaSquared_differentVariance[j] ~ dgamma (1.5, 1/10)

    precision_differentVariance[j] <- 1/sigmaSquared_differentVariance [j]

    mu_differentVariance [j] ~ dnorm (120, 1/1000)
  }
}"



writeLines (mdl_differentVariance, 'bayComparisonMeans_freq2SampleTTest_differentVariance.txt')

#x defined above as data$treatment for sameVariance model
#y defined above as data$response for sameVariance model

#data.jags defined above as c ('x', 'y') for sameVariance model

parms_differentVariance <- c ('mu_differentVariance', 'sigmaSquared_differentVariance')

comparison_differentVariance.sim <- jags (data=data.jags, inits=NULL, parameters.to.save=parms_differentVariance, model.file='bayComparisonMeans_freq2SampleTTest_differentVariance.txt', n.iter=3500, n.burnin=1000, n.chains=4, n.thin=1)
comparison_differentVariance.sim #Rhat values are all at about 1, which is what we would like to see

#We perform diagnostic analysis on the ENTIRE jags result object (comparison_differentVariance.sim)

effectiveSize (comparison_differentVariance.sim) #effectiveSize seems to give acceptable results. Only s2 for distribution_2 is less than 5,000




#Convert the JAGS result to an MCMC object
differentVarianceMCMC <- as.mcmc (comparison_differentVariance.sim)
head (differentVarianceMCMC)

autocorr (differentVarianceMCMC) #We don't see any indication of problems regarding autocorrelation




#Convert the MCMC object to a matrix in order to extract the desired columns representing each POSTERIOR distribution
differentVarianceMatrix <- as.matrix (differentVarianceMCMC)
head (differentVarianceMatrix)

differentVarianceMatrixMCMC <- as.mcmc (differentVarianceMatrix)
raftery.diag (differentVarianceMatrixMCMC) #Raftery Dependence Factor is much less than 5 for each parameter



#Separate out the MCMC object data into the different POSTERIOR distribution draws
differentVariance_Distribution_1 <- differentVarianceMatrix [,c (2,4)]
head (differentVariance_Distribution_1)

differentVariance_Distribution_2 <- differentVarianceMatrix [,c (3,5)]
head (differentVariance_Distribution_2)

#Check that the POSTERIOR distributions have the same number of draws
dim (differentVariance_Distribution_1)
dim (differentVariance_Distribution_2)


#Subtract the values for Mu (Mu2 - Mu1)
differenceMu <- differentVariance_Distribution_2 [,1] - differentVariance_Distribution_1 [,1]

#Identify the 95% Credible Interval for Difference between Mu1 and Mu2 and see if "0" is in the interval
quantile (differenceMu, c (.025, .975)) #The interval is -20.015686 to -6.031656, which does NOT contain 0.
#Therefore, we conclude that there IS a difference between Mu1 and Mu2