#This reads in the output from the SAS file that produced output file 'linreg.csv' through proc mcmc
chains <- read.csv ('linreg.csv')
head (chains) #notice first chain is 20001, this is because in proc mcmc, the nbi=20000 (burn in of 20000)


sims <- as.mcmc (chains)


chains1 <- chains[,2:4] #Extract that b0, b1, and s2
head (chains1)



sims <- as.mcmc (chains1)

chains <- chains1

rm (chains1)




raftery.diag (chains) #Produces bascially the same output as the computation in SAS




effectiveSize (sims) #Produces different values from the computation in SAS



autocorr.diag (sims)



seq (3, 300, by=3)


getc <- seq (3, 30000, by=3)
chains1 <- chains[getc,] #Thinning here -> retaining only 10000

dim (chains1) #After above thinning, chains1 now only has 10000 rows


sims1 <- as.mcmc (chains1)
raftery.diag(sims1) #Now we see the Dependence Factor is WAY below 5, as we would like them to be


effectiveSize (sims1) #Effective size only cut in half


autocorr.diag (sims1) #After seeing that it passed raftery after thinning, we're happy and we can conduct analysis with FULL dataset




#Look at Mean of each parameter (2 = column = parameter)
apply (chains, 2, mean)

#Look at 95% Interval of each parameter
apply (chains, 2, quantile, c(.025, .975))

HPDinterval (sims)




