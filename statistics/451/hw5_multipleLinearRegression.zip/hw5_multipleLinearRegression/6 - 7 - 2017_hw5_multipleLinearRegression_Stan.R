
#Get current working directory
getwd ()
#Set working directory to appropriate location
setwd ('C:/Users/Steve/Desktop/Stat 451/2017/hw5_multipleLinearRegression')

#Load rstan library
library ('rstan')

#Read in the data file
multipleLinReg <- read.table ('vo2.dat', header=TRUE)
#Make sure column labels are as expected
head (multipleLinReg)


#Prepare the variables to refer to the correct data column
MaxVO2ML <- multipleLinReg$MaxVO2ML #response

N <- length (MaxVO2ML) #number of observations

#Prepare the explanatory variables
BMI <- multipleLinReg$BMI
#Age <- multipleLinReg$Age
HR <- multipleLinReg$HR
RPE <- multipleLinReg$RPE
MPH <- multipleLinReg$MPH
Gender <- multipleLinReg$Gender


#Link the above variables to the variable names declared in the '.stan' file
multipleLinReg_dat <- list (N=N, MaxVO2ML=MaxVO2ML, BMI=BMI, Age=Age, HR=HR, RPE=RPE, MPH=MPH, Gender=Gender)


fit <- stan (file='6 - 7 - 2017_hw5_multipleLinearRegression.stan', data=multipleLinReg_dat, iter=4000, warmup=2000, chains=5)

#Obtain the result
samps <- extract (fit)

#head (samps)
names (samps)

class (samps)

head (samps$beta0)


#Obtain the necessary chains
chains <- cbind (samps$beta0, samps$betaBMI, samps$betaHR, samps$betaRPE, samps$betaMPH, samps$betaGender, samps$sigma, samps$sigma2)
head (chains)


chainsMCMC <- as.mcmc (chains)
colnames (chainsMCMC) <- c ("beta0", "betaBMI", "betaHR", "betaRPE", "betaMPH", "betaGender", "sigma", "sigma2")

dim (chainsMCMC)
effectiveSize(chainsMCMC)
raftery.diag(chainsMCMC)
autocorr.diag (chainsMCMC)


table <- apply (chainsMCMC, 2, quantile, c (.025, .5, .975))
table
