getwd ()

setwd ("C:/Users/Steve/Desktop/Stat 451/2017/hw5_multipleLinearRegression")


library ('nimble')

multipleLinRegCode <- nimbleCode ({
  
  for (i in 1:n)
  {
    MaxVO2ML [i] ~ dnorm (mu [i], 1/s2)
    
    mu [i] <- beta0 + betaBMI*BMI[i] + betaMPH*MPH[i] + betaHR*HR[i] + betaRPE*RPE[i] + betaGender*Gender[i] #+betaAge*Age[i]
  }
  
  
  beta0 ~ dnorm (0, .0001)
  betaBMI ~ dnorm (0, .0001)
  #betaAge ~ dnorm (0, .0001)
  betaMPH ~ dnorm (0, .0001)
  betaHR ~ dnorm (0, .0001)
  betaRPE ~ dnorm (0, .0001)
  betaGender ~ dnorm (0, .0001)
  
  s2 ~ dgamma (1.5, .2)
  
})




data <- read.table ('vo2.dat', header=TRUE)
class (data)

#Isolate the explanatory variables
data <- data [2:8]

#Get rid of Age because we could not reject that it is 0 (for the full model).. its 95% credible interval contained 0
data <- data [-2] 

count <- length (data$MaxVO2ML)
dataConsts <- list (n=count)

dataInits <- NULL



multipleLinReg <- nimbleModel (code=multipleLinRegCode, name='multipleLinRegEx', data=data, inits=dataInits, constants=dataConsts)

#Perform an initial compilation on the model
initCompile <- compileNimble (multipleLinReg, showCompilerOutput=TRUE)


#After compiling the model, configure the MCMC object
configureMultipleLinReg <- configureMCMC (multipleLinReg, print=TRUE, thin=2)#10)
#configureMultipleLinReg$addSampler <- (target = c(''), type='RW_block') #Random Walk sampler

buildMultipleLinReg <- buildMCMC (configureMultipleLinReg)

compileMultipleLinReg <- compileNimble (buildMultipleLinReg, project=multipleLinReg, resetFunctions=TRUE)

niter <- 250000
set.seed (0)
compileMultipleLinReg$run (niter)


chains <- as.matrix (compileMultipleLinReg$mvSamples)
chains <- chains [5001:25000,]


sims <- as.mcmc (chains)


effectiveSize (sims)
raftery.diag (sims)
autocorr.diag (sims)



table <- apply (chains, 2, quantile, c (.025, .5, .975))
table
