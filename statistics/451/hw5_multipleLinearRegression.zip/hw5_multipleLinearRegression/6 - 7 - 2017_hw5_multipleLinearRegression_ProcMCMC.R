getwd ()

resultProcMCMC <- read.csv ("../6 - 7 - 2017_hw5_multipleLinearRegressionProcMCMC.csv")
head (resultProcMCMC)
tail (resultProcMCMC)

class (resultProcMCMC)


resultParameters <- resultProcMCMC [,2:9]
head (resultParameters)


resultParametersMCMC <- as.mcmc (resultParameters)


effectiveSize (resultParametersMCMC)
raftery.diag (resultParametersMCMC)
autocorr.diag (resultParametersMCMC)


table <- apply (resultParametersMCMC, 2, quantile, c(.025, .5, .975))
table
